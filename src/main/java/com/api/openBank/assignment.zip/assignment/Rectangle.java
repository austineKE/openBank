package com.api.openBank.assignment;

import java.util.Scanner;

public class Rectangle {

    static void perimeterOfRectangle(int length, int width){
        int perimeter=0;
        perimeter=2*(length+width);
        System.out.println("Perimeter is "+perimeter);

    }
    void areaOfRectangle(int length, int width){
        int areaOfRectangle=0;
        areaOfRectangle=length*width;
        System.out.println("Area is "+areaOfRectangle);
    }
    public static void main(String[] args){

        Scanner scanner=new Scanner(System.in);
        System.out.println("Choose what to compute\n1. Area of Square. \n2. Perimeter of square");
        int choice=scanner.nextInt();
        if (choice == 2){
            perimeterOfRectangle(20,15);
        }
        else if (choice==1){
            Rectangle rectangle=new Rectangle();
            rectangle.areaOfRectangle(20,15);
        }
        else {
            System.out.println("Invalid choice");
        }


    }
}
