package com.api.openBank.assignment;

import java.util.Scanner;

public class Circle {
    static void perimeterOfCircle(double radius){
        double perimeter=0;
        perimeter=2*Math.PI*radius;
        double rounded = Math. round(perimeter * 100.0) / 100.0;
        System.out.println("Perimeter is "+rounded);
    }
    void areaOfCircle(double radius){
        double areaOfCircle=0;
        areaOfCircle=Math.PI*radius*radius;
        double rounded = Math. round(areaOfCircle * 100.0) / 100.0;
        System.out.println("Area is "+rounded);
    }

    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Choose what to compute\n1. Area of Square. \n2. Perimeter of square");
        int choice=scanner.nextInt();
        if (choice == 2){
            perimeterOfCircle(21);
        }
        else if (choice==1){
            Circle circle=new Circle();
            circle.areaOfCircle(21);
        }
        else {
            System.out.println("Invalid choice");
        }
    }
}
