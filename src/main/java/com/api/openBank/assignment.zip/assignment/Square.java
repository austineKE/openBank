package com.api.openBank.assignment;

import java.util.Scanner;

public class Square {

    static void perimeterOfSquare(int length){
        int perimeter=0;
        perimeter=4*length;
        System.out.println("Perimeter is "+perimeter);
    }
    void areaOfSquare(int length){
        int areaOfSquare=0;
        areaOfSquare=length*length;
        System.out.println("Area is " +areaOfSquare);

    }
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Choose what to compute\n1. Area of Square. \n2. Perimeter of square");
        int choice=scanner.nextInt();
        if (choice == 2){
            perimeterOfSquare(35);
        }
        else if (choice==1){
            Square square=new Square();
            square.areaOfSquare(35);
        }
        else {
            System.out.println("Invalid choice");
        }
    }
}
